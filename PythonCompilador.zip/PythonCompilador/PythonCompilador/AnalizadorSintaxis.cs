﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using IronPython.Hosting;
using Microsoft.Scripting.Hosting;

namespace PythonCompilador
{
    // Clase principal que realiza el análisis de sintaxis de código Python
    public class AnalizadorSintaxis
    {
        private ScriptEngine motor; // Motor de script de IronPython
        private ScriptScope alcance; // Alcance del script para almacenar variables y funciones
        private StringBuilder constructorSalida; // Constructor para almacenar la salida del script
        private List<(string, Regex)> patronesLenguaje; // Lista de patrones de sintaxis de Python

        // Constructor de la clase
        public AnalizadorSintaxis()
        {
            // Inicializa el motor de script de IronPython
            motor = Python.CreateEngine();
            // Crea un nuevo alcance para el script
            alcance = motor.CreateScope();
            // Inicializa el StringBuilder para almacenar la salida
            constructorSalida = new StringBuilder();

            // Crea un flujo de salida personalizado para redirigir la salida del script al StringBuilder
            var flujoSalida = new StreamEscritorString(constructorSalida);
            motor.Runtime.IO.SetOutput(flujoSalida, Encoding.UTF8);

            // Inicializa la lista de patrones de sintaxis para detectar construcciones del lenguaje Python
            patronesLenguaje = new List<(string, Regex)>
            {
                // Cada tupla contiene una etiqueta "Python" y una expresión regular para detectar una construcción específica
                ("Python", new Regex(@"^def\s+\w+\s*\(.*\)\s*:", RegexOptions.IgnoreCase)), // Definición de función
                ("Python", new Regex(@"^if\s+.*:", RegexOptions.IgnoreCase)), // Sentencia if
                ("Python", new Regex(@"^elif\s+.*:", RegexOptions.IgnoreCase)), // Sentencia elif
                ("Python", new Regex(@"^else\s*:", RegexOptions.IgnoreCase)), // Sentencia else
                ("Python", new Regex(@"^for\s+\w+\s+in\s+\w+\s*:", RegexOptions.IgnoreCase)), // Bucle for
                ("Python", new Regex(@"^while\s+.*:", RegexOptions.IgnoreCase)), // Bucle while
                ("Python", new Regex(@"^try\s*:", RegexOptions.IgnoreCase)), // Bloque try
                ("Python", new Regex(@"^except\s+.*:", RegexOptions.IgnoreCase)), // Bloque except
                ("Python", new Regex(@"^finally\s*:", RegexOptions.IgnoreCase)), // Bloque finally
                ("Python", new Regex(@"^class\s+\w+\s*:", RegexOptions.IgnoreCase)), // Definición de clase
                ("Python", new Regex(@"^import\s+\w+", RegexOptions.IgnoreCase)), // Importación de módulo
                ("Python", new Regex(@"^from\s+\w+\s+import\s+\w+", RegexOptions.IgnoreCase)), // Importación específica
                ("Python", new Regex(@"^return\s+.*", RegexOptions.IgnoreCase)), // Sentencia return
                ("Python", new Regex(@"^print\s*\(.*\)", RegexOptions.IgnoreCase)), // Función print
                ("Python", new Regex(@"^assert\s+.*", RegexOptions.IgnoreCase)), // Sentencia assert
                ("Python", new Regex(@"^break\s*", RegexOptions.IgnoreCase)), // Sentencia break
                ("Python", new Regex(@"^continue\s*", RegexOptions.IgnoreCase)), // Sentencia continue
                ("Python", new Regex(@"^del\s+.*", RegexOptions.IgnoreCase)), // Sentencia del
                ("Python", new Regex(@"^global\s+.*", RegexOptions.IgnoreCase)), // Declaración global
                ("Python", new Regex(@"^nonlocal\s+.*", RegexOptions.IgnoreCase)), // Declaración nonlocal
                ("Python", new Regex(@"^pass\s*", RegexOptions.IgnoreCase)), // Sentencia pass
                ("Python", new Regex(@"^raise\s+.*", RegexOptions.IgnoreCase)), // Sentencia raise
                ("Python", new Regex(@"^with\s+.*:", RegexOptions.IgnoreCase)), // Context manager con with
                ("Python", new Regex(@"^yield\s+.*", RegexOptions.IgnoreCase)), // Sentencia yield
                ("Python", new Regex(@"\bFalse\b", RegexOptions.IgnoreCase)), // Literal False
                ("Python", new Regex(@"\bNone\b", RegexOptions.IgnoreCase)), // Literal None
                ("Python", new Regex(@"\bTrue\b", RegexOptions.IgnoreCase)), // Literal True
                ("Python", new Regex(@"\band\b", RegexOptions.IgnoreCase)), // Operador lógico and
                ("Python", new Regex(@"\bas\b", RegexOptions.IgnoreCase)), // Palabra clave as
                ("Python", new Regex(@"\basync\b", RegexOptions.IgnoreCase)), // Palabra clave async
                ("Python", new Regex(@"\bawait\b", RegexOptions.IgnoreCase)), // Palabra clave await
                ("Python", new Regex(@"\bin\b", RegexOptions.IgnoreCase)), // Operador in
                ("Python", new Regex(@"\bis\b", RegexOptions.IgnoreCase)), // Operador is
                ("Python", new Regex(@"\blambda\b", RegexOptions.IgnoreCase)), // Palabra clave lambda
                ("Python", new Regex(@"\bnot\b", RegexOptions.IgnoreCase)), // Operador lógico not
                ("Python", new Regex(@"\bor\b", RegexOptions.IgnoreCase)) // Operador lógico or
            };
        }

        // Método para ejecutar código Python y obtener la salida
        public string EjecutarCodigoPython(string codigo)
        {
            try
            {
                // Limpia el contenido del StringBuilder
                constructorSalida.Clear();
                // Crea una fuente de script a partir del código proporcionado
                var fuente = motor.CreateScriptSourceFromString(codigo);
                // Ejecuta el código en el alcance
                fuente.Execute(alcance);
                // Devuelve el resultado de la ejecución
                return $"Ejecución exitosa.\n\nResultado de la ejecución:\n{constructorSalida.ToString()}";
            }
            catch (Exception ex)
            {
                // Devuelve el mensaje de error en caso de excepción
                return $"Error durante la ejecución del código: {ex.Message}";
            }
        }

        // Clase interna que actúa como un flujo de escritura personalizado para StringBuilder
        private class StreamEscritorString : Stream
        {
            private StringBuilder constructorString;

            public StreamEscritorString(StringBuilder constructorString)
            {
                this.constructorString = constructorString;
            }

            public override bool CanRead => false;
            public override bool CanSeek => false;
            public override bool CanWrite => true;
            public override long Length => 0;
            public override long Position { get => 0; set => throw new NotSupportedException(); }
            public override void Flush() { }
            public override int Read(byte[] buffer, int offset, int count) => throw new NotSupportedException();
            public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
            public override void SetLength(long value) => throw new NotSupportedException();
            public override void Write(byte[] buffer, int offset, int count)
            {
                // Convierte los bytes del buffer en una cadena utilizando codificación UTF8
                var texto = Encoding.UTF8.GetString(buffer, offset, count);
                // Agrega la cadena al StringBuilder
                constructorString.Append(texto);
            }
        }
    }
}