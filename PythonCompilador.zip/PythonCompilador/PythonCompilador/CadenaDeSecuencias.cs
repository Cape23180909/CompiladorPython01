﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PythonCompilador
{
    // La clase CadenaDeSecuencias hereda de Stream y se utiliza para escribir en un StringBuilder.
    public class CadenaDeSecuencias : Stream
    {
        // Campo privado que almacena una referencia al StringBuilder.
        private StringBuilder Constructor;

        // Constructor de la clase que recibe un StringBuilder y lo asigna al campo privado.
        public CadenaDeSecuencias(StringBuilder constructor)
        {
            Constructor = constructor;
        }

        // Propiedades que indican las capacidades del Stream.
        public override bool CanRead => false; // No se puede leer desde este Stream.
        public override bool CanSeek => false; // No se puede buscar en este Stream.
        public override bool CanWrite => true; // Se puede escribir en este Stream.

        // Propiedad que devuelve la longitud del Stream.
        public override long Length => 0; // No tiene longitud definida.

        // Propiedad que controla la posición actual en el Stream.
        public override long Position
        {
            get => 0; // La posición siempre es 0 porque no se puede buscar.
            set => throw new NotSupportedException(); // No se puede establecer la posición.
        }

        // Método Flush que no hace nada, ya que no hay buffer que vaciar.
        public override void Flush() { }

        // Método Read que lanza una excepción porque no se puede leer.
        public override int Read(byte[] buffer, int offset, int count) => throw new NotSupportedException();

        // Método Seek que lanza una excepción porque no se puede buscar.
        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();

        // Método SetLength que lanza una excepción porque no se puede establecer la longitud.
        public override void SetLength(long value) => throw new NotSupportedException();

        // Método Write que escribe los datos del buffer en el StringBuilder.
        public override void Write(byte[] buffer, int offset, int count)
        {
            // Convierte los bytes del buffer en una cadena utilizando codificación UTF8.
            var texto = Encoding.UTF8.GetString(buffer, offset, count);
            // Agrega la cadena al StringBuilder.
            Constructor.Append(texto);
        }
    }
}