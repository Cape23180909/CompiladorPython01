﻿using System;
using System.Text;
using System.Windows;
using IronPython.Hosting;
using Microsoft.Scripting.Hosting;

namespace PythonCompilador
{
    // Clase VentanaPrincipal que hereda de Window y representa la ventana principal de la aplicación WPF
    public partial class VentanaPrincipal : Window
    {
        private AnalizadorSintaxis analizador; // Instancia del AnalizadorSintaxis para ejecutar código Python

        // Constructor de la clase VentanaPrincipal
        public VentanaPrincipal()
        {
            InitializeComponent(); // Inicializa los componentes de la interfaz gráfica
            analizador = new AnalizadorSintaxis(); // Crea una nueva instancia del AnalizadorSintaxis
        }

        // Método que se llama cuando se hace clic en el botón de analizar
        private void AlHacerClickAnalizar(object sender, RoutedEventArgs e)
        {
            // Obtiene el código Python del cuadro de texto
            string codigo = CuadroTextoCodigo.Text;
            // Ejecuta el código Python utilizando el analizador y obtiene el resultado
            string resultado = analizador.EjecutarCodigoPython(codigo);
            // Muestra el resultado en el bloque de texto de la interfaz
            BloqueTextoResultado.Text = resultado;
        }

        // Método que se llama cuando se hace clic en el botón de limpiar pantalla
        private void AlHacerClickLimpiarPantalla(object sender, RoutedEventArgs e)
        {
            // Limpia el contenido del cuadro de texto del código
            CuadroTextoCodigo.Clear();
            // Limpia el contenido del bloque de texto del resultado
            BloqueTextoResultado.Clear();
        }
    }
}